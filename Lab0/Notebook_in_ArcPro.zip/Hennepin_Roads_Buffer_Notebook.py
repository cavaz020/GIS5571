import arcpy

arcpy.analysis.Buffer(in_features = "MN_Roads_Clip.shp", out_feature_class = "Hennepin_Roads_Buffer.shp", buffer_distance_or_field = "300 Meters", dissolve_option = "ALL")




