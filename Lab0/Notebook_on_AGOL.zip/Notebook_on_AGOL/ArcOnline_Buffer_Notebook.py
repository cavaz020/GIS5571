#!/usr/bin/env python
# coding: utf-8

# ## Welcome to your notebook.
# 

# #### Run this cell to connect to your GIS and get started:

# In[4]:


from arcgis.gis import GIS
gis = GIS("home")


# #### Now you are ready to start!

# In[5]:


# Item Added From Toolbar
# Title: Hennepin_Roads_Clip | Type: Feature Service | Owner: cavaz020_UMN
Hennepin_roads = gis.content.get("cfc4b01218e24f13bdb2f4ad17265d69")
Hennepin_roads


# In[6]:


from arcgis import features
features.use_proximity.create_buffers(input_layer=Hennepin_roads,
                         distances=[300],
                         units='Meters',
                         dissolve_type = 'Dissolve',
                         output_name='Hennepin_road_buffer')

